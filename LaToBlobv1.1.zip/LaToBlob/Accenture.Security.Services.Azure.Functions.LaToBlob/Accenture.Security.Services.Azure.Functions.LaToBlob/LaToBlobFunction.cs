//-----------------------------------------------------------------------
// <copyright file="LaToBlobFunction.cs" company="Accenture">
//      Copyright (c) Accenture. All rights reserved.
// </copyright>
// <author>Accenture Security</author>
//-----------------------------------------------------------------------
namespace Accenture.Security.Services.Azure.Functions.LaToBlob
{
    // .NET Namespaces.
    using System;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    // Fels�kning Namespaces.
    using Fels�kning.Utilities.Azure;
    using Fels�kning.Utilities.SvenskaUtilities;

    // Microsoft Namespaces.
    using Microsoft.Azure.WebJobs;
    using Microsoft.Extensions.Logging;
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.Blob;

    /// <summary>
    ///     Initializes a new instance of the <see cref="LaToBlobFunction"/> class.
    /// </summary>
    public static class LaToBlobFunction
    {
        /// <summary>
        ///     The method body that is invoked on the timer elapsed (function infrastructure).
        /// </summary>
        /// <param name="myTimer">The defined timer for the Azure Function instance.</param>
        /// <param name="log">The log stream to write eventing to.</param>
        [FunctionName("Function1")] // TODO: Change. All names must be unique across Azure.
        public static void Run([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"LaToBlob started at {DateTime.UtcNow.ToSwedishString()}");

            // Environment variables in Azure; local.settings.json for local debugging.
            bool appendQueryResults = bool.Parse(value: Environment.GetEnvironmentVariable(variable: "AppendResults"));
            string laQuery = Environment.GetEnvironmentVariable(variable: "LaQuery");
            string csaConnectionString = Environment.GetEnvironmentVariable(variable: "CsaConnectionString");
            string cbbContainer = Environment.GetEnvironmentVariable(variable: "CbbContainer");
            string tenantId = Environment.GetEnvironmentVariable(variable: "TenantId");
            string workspaceId = Environment.GetEnvironmentVariable(variable: "WorkspaceId");

            if (string.IsNullOrWhiteSpace(value: laQuery)
                || string.IsNullOrWhiteSpace(value: csaConnectionString)
                || string.IsNullOrWhiteSpace(value: cbbContainer)
                || string.IsNullOrWhiteSpace(value: tenantId)
                || string.IsNullOrWhiteSpace(value: workspaceId))
            {
                throw new ArgumentNullException();
            }

            if (!Guid.TryParse(input: tenantId, out _) || !Guid.TryParse(input: workspaceId, out _))
            {
                throw new ArgumentException();
            }

            using (LogAnalyticsQueryWrapper laQueryWrapper = new LogAnalyticsQueryWrapper(tenantId: tenantId, workspaceId: workspaceId))
            {
                LaQueryResult laQueryResult = laQueryWrapper.SubmitQuery(laQuery: laQuery);
                StringBuilder stringBuilder = new StringBuilder();
                string columnsString = string.Empty;

                // Handle possibility for multiple tables.
                Parallel.ForEach(
                    laQueryResult.Tables,
                    table =>
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(connectionString: csaConnectionString);
                    CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                    CloudBlockBlob cloudBlockBlob = cloudBlobClient
                        .GetContainerReference(containerName: cbbContainer)
                        .GetBlockBlobReference(blobName: $"{table.TableName}.csv"); // File name derived from table name.

                    if (appendQueryResults)
                    {
                        string alreadyPresentContent = cloudBlockBlob.DownloadTextAsync().Result;
                        stringBuilder.Append(value: alreadyPresentContent);
                    }

                    if (!appendQueryResults || (appendQueryResults && string.IsNullOrWhiteSpace(value: stringBuilder.ToString())))
                    {
                        string columnsString = string.Empty;
                        table.Columns.ForEach(c =>
                        {
                            columnsString += c.Name.ToString() + ",";
                        });

                        stringBuilder.AppendLine(value: columnsString);
                    }

                    table.Rows.ForEach(r =>
                    {
                        stringBuilder.AppendLine(string.Join(separator: ',', values: r.Select(s => s)));
                    });

                    cloudBlockBlob.UploadTextAsync(content: stringBuilder.ToString());

                    log.LogInformation($"LaToBlob finished uploading {table.TableName}.csv to Azure Blob Storage at {DateTime.UtcNow.ToSwedishString()}.");
                });
            }

            log.LogInformation($"LaToBlob completed at {DateTime.UtcNow.ToSwedishString()}. Next iteration is at {myTimer.Schedule.GetNextOccurrence(DateTime.UtcNow).ToSwedishString()}");
        }
    }
}